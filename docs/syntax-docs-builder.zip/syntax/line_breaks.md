# Line breaks

A new line in markdown starts a new paragraph. This is the standard way to separate distinct blocks of text.

## Forced Line Breaks
If you need to force a line break within a paragraph without starting a new one, you can use `<br>`. Only `<br>` is supported; variations like `</br>` are not supported.