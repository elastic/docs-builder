# Tagged regions

```{warning}
This feature will not be supported in Elastic Docs V3. See [File inclusion](./file_inclusion.md) for an alternative.
```
