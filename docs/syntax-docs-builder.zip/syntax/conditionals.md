# Conditionals

:::{warning}
This feature will not be supported in Elastic Docs V3.
:::